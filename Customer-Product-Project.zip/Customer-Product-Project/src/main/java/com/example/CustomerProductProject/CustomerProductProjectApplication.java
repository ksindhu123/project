package com.example.CustomerProductProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomerProductProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomerProductProjectApplication.class, args);
	}

}
