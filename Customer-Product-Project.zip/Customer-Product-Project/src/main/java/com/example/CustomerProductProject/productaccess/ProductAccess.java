package com.example.CustomerProductProject.productaccess;

public class ProductAccess {
	
	//private Long productID;
	
	private String productName;
	
	private int discount;
	
	private double price;

//	public Long getProductID() {
//		return productID;
//	}
//
//	public void setProductID(Long productID) {
//		this.productID = productID;
//	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getDiscount() {
		return discount;
	}

	public void setDiscount(int discount) {
		this.discount = discount;
	}
	

}
