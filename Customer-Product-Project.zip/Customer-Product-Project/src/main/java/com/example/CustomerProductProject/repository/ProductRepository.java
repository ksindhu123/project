package com.example.CustomerProductProject.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.CustomerProductProject.entity.Product;


public interface ProductRepository extends JpaRepository<Product, Long>{

	public Product findByProductNameIgnoreCase(String productName);
	
	
	//Products matching same name
	public List<Product> findByProductName(String productName);
	
	@Query(value = "select * from Customer_Schema.product p where p.price<:price", nativeQuery = true)
	public List<Product> findByProductsWithPriceGreaterThanHunderd(double price);


}
