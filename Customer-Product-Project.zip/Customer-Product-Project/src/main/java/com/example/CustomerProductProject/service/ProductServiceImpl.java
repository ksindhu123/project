package com.example.CustomerProductProject.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.CustomerProductProject.entity.Product;
import com.example.CustomerProductProject.model.ProductModel;
import com.example.CustomerProductProject.productaccess.ProductAccess;
import com.example.CustomerProductProject.repository.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	private ProductRepository productRepository;

	@Override
	public Product saveProduct(Product product) {
		// TODO Auto-generated method stub
		return productRepository.save(product);
	}

	@Override
	public List<Product> findAllProducts() {
		// TODO Auto-generated method stub
		return productRepository.findAll();
	}

	@Override
	public Product getProductById(Long productID) {
		// TODO Auto-generated method stub
		return productRepository.findById(productID).get();
	}

	@Override
	public Product updateProduct(Product product, Long productID) {
		// TODO Auto-generated method stub
		Product prodDB = productRepository.findById(productID).get();

		if (Objects.nonNull(product.getProductName()) && !"".equalsIgnoreCase(product.getProductName())) {
			prodDB.setProductName(product.getProductName());
		}

		if (Objects.nonNull(product.getPrice())) {
			prodDB.setPrice(product.getPrice());
		}
		
		if (Objects.nonNull(product.getDiscount())) {
			prodDB.setDiscount(product.getDiscount());
		}
		
		return productRepository.save(prodDB);
	}

	@Override
	public void deleteProduct(Long productID) {
		// TODO Auto-generated method stub
		productRepository.deleteById(productID);
	}

	@Override
	public Product getProductByName(String productName) {
		// TODO Auto-generated method stub
		return productRepository.findByProductNameIgnoreCase(productName);
	}

	@Override
	public List<Product> getAllProductsByName(String productName) {
		// TODO Auto-generated method stub
		return productRepository.findByProductName(productName);
	}

	@Override
	public List<ProductAccess> getProductDiscount() {
		// TODO Auto-generated method stub
		List<Product> getProductDetails = productRepository.findAll();
		//Product p = new Product();
		List<ProductAccess> productAccess = new ArrayList<ProductAccess>();
		for(Product product : getProductDetails) {
			ProductAccess pa = new ProductAccess();
			//pa.setProductID((long) 1253587);
			pa.setProductName(product.getProductName());
			pa.setPrice(product.getPrice());
			int discount = product.getDiscount();
			pa.setDiscount(product.multiplyDiscount(discount));
			
			productAccess.add(pa);
		}
		System.out.println(productAccess.size());
		return productAccess;
	}

	@Override
	public List<Product> getAllProductsWithPriceHundred(double price) {
		// TODO Auto-generated method stub
		return productRepository.findByProductsWithPriceGreaterThanHunderd(price);
	}
	
	//React UI implementation Api's falls below

	@Override
	public ProductModel createOrder(ProductModel productModel) {
		// TODO Auto-generated method stub
		Product product = new Product();
		BeanUtils.copyProperties(productModel, product);
		productRepository.save(product);
		return productModel;
		
	}

	@Override
	public List<ProductModel> getAllProducts() {
		// TODO Auto-generated method stub
		List<Product> allProducts = productRepository.findAll();
		List<ProductModel> products = new ArrayList<ProductModel>();
		for(Product product : allProducts) {
			ProductModel pm = new ProductModel();
			pm.setProductID(product.getProductID());
			pm.setProductName(product.getProductName());
			pm.setPrice(product.getPrice());
			pm.setDiscount(product.getDiscount());
			products.add(pm);
		}
		return products;
	}

	@Override
	public boolean deleteProductUi(Long productID) {
		// TODO Auto-generated method stub
		 Product product = productRepository.findById(productID).get();
		 productRepository.delete(product);
	        return true;
	}

	@Override
	public ProductModel getProductByIdUi(Long productID) {
		// TODO Auto-generated method stub
		Product product = productRepository.findById(productID).get();
		ProductModel productModel = new ProductModel();
		BeanUtils.copyProperties(product, productModel);
		return productModel;
	}

	@Override
	public ProductModel updateProductByIdUi(Long productID, ProductModel productModel) {
		// TODO Auto-generated method stub
		Product product = productRepository.findById(productID).get();
		product.setProductName(productModel.getProductName());
		product.setPrice(productModel.getPrice());
		product.setDiscount(productModel.getDiscount());
		productRepository.save(product);
		return productModel;
	}
}
