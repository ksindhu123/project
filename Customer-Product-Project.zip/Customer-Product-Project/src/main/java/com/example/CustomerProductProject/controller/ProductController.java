package com.example.CustomerProductProject.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.CustomerProductProject.entity.Product;
import com.example.CustomerProductProject.model.ProductModel;
import com.example.CustomerProductProject.productaccess.ProductAccess;
import com.example.CustomerProductProject.service.ProductService;

import jakarta.validation.Valid;


@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/products")
public class ProductController {
	
	@Autowired
	private ProductService productService;

	@GetMapping("/welcome")
	public String greetmessage() {
		return "Welcome to customer ordered products";
	}
	
	@PostMapping("/saveproduct")
	public Product saveProduct(@Valid @RequestBody Product product) {
		return productService.saveProduct(product);
	}
	
	@GetMapping("/findallproducts")
	public List<Product> findAllProducts(){
		return productService.findAllProducts();
	}
	
	@GetMapping("/getproductbyid/{id}")
	public Product getProductById(@PathVariable("id") Long productID) {
		return productService.getProductById(productID);
	}
	
	//products matching same name
	@GetMapping("/products/name/{name}")
	public List<Product> getAllProductsByName(@PathVariable("name") String productName){
		return productService.getAllProductsByName(productName);
	}
	
	//accessing single product
	@GetMapping("/product/name/{name}")
	public Product getProductByName(@PathVariable("name") String productName) {
		return productService.getProductByName(productName);
	}
	
	@PutMapping("/updateproduct/{id}")
	public Product updateProduct(@RequestBody Product product, @PathVariable("id") Long productID) {
		return productService.updateProduct(product, productID);
	}
	
	@DeleteMapping("/deleteproduct/{id}")
	public String deleteProduct(@PathVariable("id") Long productID) {
		productService.deleteProduct(productID);
		return "Customer deleted successfully";
	}
	
	
	//Product Access Api's
	@GetMapping("/product/getproductdiscount")
	List<ProductAccess> getProductDiscount(){
		return productService.getProductDiscount();
	}
	
	//Native query 
	@GetMapping("/productsgreaterthantwohunderd/{price}")
	public List<Product> getAllProductsWithPriceHundred(@PathVariable("price") double price){
		return productService.getAllProductsWithPriceHundred(price);
	}
	
	//React Ui implementation follows
	
	@PostMapping("/createorder")
	public ProductModel createOrder(@RequestBody ProductModel productModel) {
		return productService.createOrder(productModel);
	}
	
	@GetMapping("/createorder/displayallproducts")
	public List<ProductModel> getAllProducts(){
		return productService.getAllProducts();
	}
	
	@DeleteMapping("/deleteproductui/{id}")
    public ResponseEntity<Map<String,Boolean>> deleteProductUi(@PathVariable("id") Long productID) {
        boolean deleted = false;
        deleted = productService.deleteProductUi(productID);
        Map<String,Boolean> response = new HashMap<>();
        response.put("deleted", deleted);
        return ResponseEntity.ok(response);
    }
	
	@GetMapping("getproductsbyidui/{id}")
	public ProductModel getProductByIdUi(@PathVariable("id") Long productID) {
		return productService.getProductByIdUi(productID);
	}
	
	@PutMapping("updateproductsbyidui/{id}")
	public ProductModel updateProductByIdUi(@PathVariable("id") Long productID, @RequestBody ProductModel productModel) {
		return productService.updateProductByIdUi(productID,productModel);
	}

	
}
