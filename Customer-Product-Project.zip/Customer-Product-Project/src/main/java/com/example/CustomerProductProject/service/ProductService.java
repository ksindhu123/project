package com.example.CustomerProductProject.service;

import java.util.List;

import com.example.CustomerProductProject.entity.Product;
import com.example.CustomerProductProject.model.ProductModel;
import com.example.CustomerProductProject.productaccess.ProductAccess;

public interface ProductService {

	Product saveProduct(Product product);

	List<Product> findAllProducts();

	Product getProductById(Long productID);

	Product updateProduct(Product product, Long productID);

	void deleteProduct(Long productID);

	Product getProductByName(String productName);

	List<Product> getAllProductsByName(String productName);

	List<ProductAccess> getProductDiscount();

	List<Product> getAllProductsWithPriceHundred(double price);

	ProductModel createOrder(ProductModel productModel);

	List<ProductModel> getAllProducts();

	boolean deleteProductUi(Long productID);

	ProductModel getProductByIdUi(Long productID);

	ProductModel updateProductByIdUi(Long productID, ProductModel productModel);

}
