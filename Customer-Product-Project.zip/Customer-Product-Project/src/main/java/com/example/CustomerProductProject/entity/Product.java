package com.example.CustomerProductProject.entity;



//import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;

@Entity
@Table(name="product")
public class Product {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "product_id")
	private Long productID;
	
	@NotBlank(message = "Product name should be entered")
	@Column(name = "product_name")
    private String productName;
	
	
	@Column(name = "price")
    private double price;
	
	@Column(name = "discont")
	private int discount;

	public Long getProductID() {
		return productID;
	}

	public void setProductID(Long productID) {
		this.productID = productID;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getDiscount() {
		return discount;
	}

	public void setDiscount(int discount) {
		this.discount = discount;
	}
	
	public int multiplyDiscount(int discount) {
		return (discount = discount * 100);
	}
	
//	@Column(name = "product_create_date")
//    private Date productCreationDate;
	
//	@Column(name = "is_expired_productl")
//	private boolean isExpiredProduct;

	

	

}
